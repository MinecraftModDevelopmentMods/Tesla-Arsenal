package cyano.basemetals.init;

/**
 * This class contains static initializers to add world gen stuff
 * @author DrCyano
 *
 */
public abstract class WorldGen {

	


	public static void init(){
		// do nothing, for now
	}


}
